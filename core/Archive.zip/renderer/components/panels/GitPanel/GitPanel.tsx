import React, { useState, useCallback } from 'react';
import { useGit } from '@/contexts/GitContext';
import { useGitHub } from '@/contexts/GitHubContext';
import { 
  GitBranchIcon, GitCommitIcon, GitPullRequestIcon, RefreshIcon, 
  UploadIcon, DownloadIcon, PlusIcon, XIcon, CheckIcon, 
  GitHubIcon, TrashIcon, FolderIcon, FileIcon
} from '@/components/ui/icons';
import './GitPanel.css';

type TabType = 'changes' | 'history' | 'branches';

interface GitPanelProps {
  onConnectClick: () => void;
}

export const GitPanel: React.FC<GitPanelProps> = ({ onConnectClick }) => {
  const {
    isInitialized,
    isLoading,
    error,
    status,
    commits,
    branches,
    currentBranch,
    remotes,
    workspacePath,
    
    initRepo,
    refreshStatus,
    refreshAll,
    
    stageFile,
    stageAll,
    unstageFile,
    discardChanges,
    
    commit,
    
    createBranch,
    checkoutBranch,
    deleteBranch,
    
    addRemote,
    removeRemote,
    
    push,
    pull,
    
    getTotalChanges,
    hasChanges,
  } = useGit();

  const { isAuthenticated, user } = useGitHub();

  const [activeTab, setActiveTab] = useState<TabType>('changes');
  const [commitMessage, setCommitMessage] = useState('');
  const [isCommitting, setIsCommitting] = useState(false);
  const [isPushing, setIsPushing] = useState(false);
  const [isPulling, setIsPulling] = useState(false);
  const [showNewBranchInput, setShowNewBranchInput] = useState(false);
  const [newBranchName, setNewBranchName] = useState('');
  const [showAddRemoteModal, setShowAddRemoteModal] = useState(false);
  const [newRemoteName, setNewRemoteName] = useState('origin');
  const [newRemoteUrl, setNewRemoteUrl] = useState('');

  // Handle init repo
  const handleInitRepo = useCallback(async () => {
    await initRepo();
  }, [initRepo]);

  // Handle refresh
  const handleRefresh = useCallback(async () => {
    await refreshAll();
  }, [refreshAll]);

  // Handle commit
  const handleCommit = useCallback(async () => {
    if (!commitMessage.trim()) return;
    
    setIsCommitting(true);
    const result = await commit(commitMessage);
    setIsCommitting(false);
    
    if (result.success) {
      setCommitMessage('');
    }
  }, [commitMessage, commit]);

  // Handle push
  const handlePush = useCallback(async () => {
    setIsPushing(true);
    await push();
    setIsPushing(false);
  }, [push]);

  // Handle pull
  const handlePull = useCallback(async () => {
    setIsPulling(true);
    await pull();
    setIsPulling(false);
  }, [pull]);

  // Handle stage all
  const handleStageAll = useCallback(async () => {
    await stageAll();
  }, [stageAll]);

  // Handle create branch
  const handleCreateBranch = useCallback(async () => {
    if (!newBranchName.trim()) return;
    
    const result = await createBranch(newBranchName, true);
    if (result.success) {
      setNewBranchName('');
      setShowNewBranchInput(false);
    }
  }, [newBranchName, createBranch]);

  // Handle add remote
  const handleAddRemote = useCallback(async () => {
    if (!newRemoteName.trim() || !newRemoteUrl.trim()) return;
    
    const result = await addRemote(newRemoteName, newRemoteUrl);
    if (result.success) {
      setNewRemoteName('origin');
      setNewRemoteUrl('');
      setShowAddRemoteModal(false);
    }
  }, [newRemoteName, newRemoteUrl, addRemote]);

  // Format timestamp
  const formatDate = (timestamp: number) => {
    const date = new Date(timestamp * 1000);
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    
    if (diff < 60000) return 'just now';
    if (diff < 3600000) return `${Math.floor(diff / 60000)}m ago`;
    if (diff < 86400000) return `${Math.floor(diff / 3600000)}h ago`;
    if (diff < 604800000) return `${Math.floor(diff / 86400000)}d ago`;
    
    return date.toLocaleDateString();
  };

  // No workspace selected
  if (!workspacePath) {
    return (
      <div className="git-panel">
        <div className="git-panel__header">
          <h3>
            <GitBranchIcon />
            Git
          </h3>
        </div>
        <div className="git-panel__not-connected">
          <FolderIcon />
          <h4>No Workspace Selected</h4>
          <p>
            Select a workspace to use Git version control.
          </p>
        </div>
      </div>
    );
  }

  // Not initialized - show init button
  if (!isInitialized) {
    return (
      <div className="git-panel">
        <div className="git-panel__header">
          <h3>
            <GitBranchIcon />
            Git
          </h3>
        </div>
        <div className="git-panel__not-connected">
          <GitBranchIcon />
          <h4>Initialize Repository</h4>
          <p>
            This workspace is not a Git repository yet. Initialize it to start tracking changes.
          </p>
          <button 
            className="git-panel__connect-btn" 
            onClick={handleInitRepo}
            disabled={isLoading}
          >
            <GitBranchIcon />
            {isLoading ? 'Initializing...' : 'Initialize Git Repository'}
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="git-panel">
      <div className="git-panel__header">
        <h3>
          <GitBranchIcon />
          Git
        </h3>
        <div className="git-panel__actions">
          <button 
            className="git-panel__action-btn"
            onClick={handleRefresh}
            disabled={isLoading}
            title="Refresh"
          >
            <span className={isLoading ? 'spin' : ''}>
              <RefreshIcon />
            </span>
          </button>
        </div>
      </div>

      {/* Branch info */}
      <div className="git-panel__repo-info">
        <div className="repo-avatar">
          <GitBranchIcon />
        </div>
        <div className="repo-details">
          <div className="repo-name">{currentBranch || 'main'}</div>
          <div className="repo-branch">
            {remotes.length > 0 ? (
              <>
                <span className="remote-indicator">●</span>
                {remotes[0].name}
              </>
            ) : (
              <span className="no-remote">No remote configured</span>
            )}
          </div>
        </div>
        {!isAuthenticated && remotes.length === 0 && (
          <button 
            className="git-panel__connect-btn git-panel__connect-btn--small"
            onClick={onConnectClick}
            title="Connect GitHub to push/pull"
          >
            <GitHubIcon />
          </button>
        )}
      </div>

      {/* Error display */}
      {error && (
        <div className="git-panel__error">
          <XIcon />
          <span>{error}</span>
        </div>
      )}

      {/* Tabs */}
      <div className="git-panel__tabs">
        <button
          className={`git-panel__tab ${activeTab === 'changes' ? 'git-panel__tab--active' : ''}`}
          onClick={() => setActiveTab('changes')}
        >
          <GitPullRequestIcon />
          Changes
          {getTotalChanges() > 0 && (
            <span className="badge">{getTotalChanges()}</span>
          )}
        </button>
        <button
          className={`git-panel__tab ${activeTab === 'history' ? 'git-panel__tab--active' : ''}`}
          onClick={() => setActiveTab('history')}
        >
          <GitCommitIcon />
          History
        </button>
        <button
          className={`git-panel__tab ${activeTab === 'branches' ? 'git-panel__tab--active' : ''}`}
          onClick={() => setActiveTab('branches')}
        >
          <GitBranchIcon />
          Branches
        </button>
      </div>

      {/* Tab content */}
      <div className="git-panel__content">
        {activeTab === 'changes' && (
          <div className="git-panel__changes">
            {/* Staged files */}
            {status && status.staged.length > 0 && (
              <div className="git-panel__section">
                <div className="git-panel__section-header">
                  <span>Staged Changes ({status.staged.length})</span>
                </div>
                {status.staged.map((file) => (
                  <div key={file.path} className="git-panel__change-file">
                    <span className={`file-status file-status--${file.status}`}>
                      {file.status === 'added' ? 'A' : file.status === 'modified' ? 'M' : 'D'}
                    </span>
                    <span className="file-name">{file.path.split('/').pop()}</span>
                    <span className="file-path">{file.path}</span>
                    <button 
                      className="file-action"
                      onClick={() => unstageFile(file.path)}
                      title="Unstage"
                    >
                      <XIcon />
                    </button>
                  </div>
                ))}
              </div>
            )}

            {/* Unstaged files */}
            {status && status.unstaged.length > 0 && (
              <div className="git-panel__section">
                <div className="git-panel__section-header">
                  <span>Changes ({status.unstaged.length})</span>
                  <button 
                    className="git-panel__stage-all"
                    onClick={handleStageAll}
                    title="Stage All"
                  >
                    <PlusIcon />
                  </button>
                </div>
                {status.unstaged.map((file) => (
                  <div key={file.path} className="git-panel__change-file">
                    <span className={`file-status file-status--${file.status}`}>
                      {file.status === 'added' ? 'A' : file.status === 'modified' ? 'M' : 'D'}
                    </span>
                    <span className="file-name">{file.path.split('/').pop()}</span>
                    <span className="file-path">{file.path}</span>
                    <div className="file-actions">
                      <button 
                        className="file-action"
                        onClick={() => stageFile(file.path)}
                        title="Stage"
                      >
                        <PlusIcon />
                      </button>
                      <button 
                        className="file-action file-action--danger"
                        onClick={() => discardChanges(file.path)}
                        title="Discard"
                      >
                        <TrashIcon />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* Untracked files */}
            {status && status.untracked.length > 0 && (
              <div className="git-panel__section">
                <div className="git-panel__section-header">
                  <span>Untracked Files ({status.untracked.length})</span>
                  <button 
                    className="git-panel__stage-all"
                    onClick={handleStageAll}
                    title="Stage All"
                  >
                    <PlusIcon />
                  </button>
                </div>
                {status.untracked.map((filepath) => (
                  <div key={filepath} className="git-panel__change-file">
                    <span className="file-status file-status--untracked">?</span>
                    <span className="file-name">{filepath.split('/').pop()}</span>
                    <span className="file-path">{filepath}</span>
                    <button 
                      className="file-action"
                      onClick={() => stageFile(filepath)}
                      title="Stage"
                    >
                      <PlusIcon />
                    </button>
                  </div>
                ))}
              </div>
            )}

            {/* No changes */}
            {!hasChanges() && (
              <div className="git-panel__changes-empty">
                <CheckIcon />
                <p>No uncommitted changes</p>
              </div>
            )}

            {/* Commit input */}
            {status && status.staged.length > 0 && (
              <div className="git-panel__commit-form">
                <textarea
                  className="git-panel__commit-input"
                  placeholder="Commit message..."
                  value={commitMessage}
                  onChange={(e) => setCommitMessage(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) {
                      handleCommit();
                    }
                  }}
                />
                <button
                  className="git-panel__commit-btn"
                  onClick={handleCommit}
                  disabled={!commitMessage.trim() || isCommitting}
                >
                  <GitCommitIcon />
                  {isCommitting ? 'Committing...' : 'Commit'}
                </button>
              </div>
            )}
          </div>
        )}

        {activeTab === 'history' && (
          <div className="git-panel__history">
            {isLoading ? (
              <div className="git-panel__loading">
                <div className="spinner" />
              </div>
            ) : commits.length === 0 ? (
              <div className="git-panel__changes-empty">
                <GitCommitIcon />
                <p>No commits yet</p>
              </div>
            ) : (
              commits.map((item) => (
                <div 
                  key={item.oid} 
                  className="git-panel__commit"
                >
                  <div className="commit-avatar">
                    {item.author.name.charAt(0).toUpperCase()}
                  </div>
                  <div className="commit-details">
                    <div className="commit-message">{item.message.split('\n')[0]}</div>
                    <div className="commit-meta">
                      <span className="commit-sha">{item.oid.substring(0, 7)}</span>
                      <span>{item.author.name}</span>
                      <span>{formatDate(item.author.timestamp)}</span>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        )}

        {activeTab === 'branches' && (
          <div className="git-panel__branches">
            <div className="git-panel__branch-list">
              {branches.map((branch) => (
                <button
                  key={branch.name}
                  className={`git-panel__branch ${
                    branch.current ? 'git-panel__branch--current' : ''
                  }`}
                  onClick={() => !branch.current && checkoutBranch(branch.name)}
                  disabled={branch.current}
                >
                  <GitBranchIcon />
                  <span className="branch-name">{branch.name}</span>
                  {branch.current && (
                    <span className="branch-badge">current</span>
                  )}
                  {!branch.current && (
                    <button
                      className="branch-delete"
                      onClick={(e) => {
                        e.stopPropagation();
                        if (confirm(`Delete branch "${branch.name}"?`)) {
                          deleteBranch(branch.name);
                        }
                      }}
                      title="Delete branch"
                    >
                      <TrashIcon />
                    </button>
                  )}
                </button>
              ))}
            </div>
            
            {showNewBranchInput ? (
              <div className="git-panel__new-branch-form">
                <input
                  type="text"
                  placeholder="Branch name..."
                  value={newBranchName}
                  onChange={(e) => setNewBranchName(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') handleCreateBranch();
                    if (e.key === 'Escape') {
                      setShowNewBranchInput(false);
                      setNewBranchName('');
                    }
                  }}
                  autoFocus
                />
                <button onClick={handleCreateBranch} disabled={!newBranchName.trim()}>
                  <CheckIcon />
                </button>
                <button onClick={() => { setShowNewBranchInput(false); setNewBranchName(''); }}>
                  <XIcon />
                </button>
              </div>
            ) : (
              <button 
                className="git-panel__new-branch"
                onClick={() => setShowNewBranchInput(true)}
              >
                <PlusIcon />
                New Branch
              </button>
            )}

            {/* Remotes section */}
            <div className="git-panel__section-header" style={{ marginTop: '16px' }}>
              <span>Remotes</span>
            </div>
            {remotes.length === 0 ? (
              <div className="git-panel__no-remotes">
                <p>No remotes configured</p>
                <button 
                  className="git-panel__add-remote-btn"
                  onClick={() => setShowAddRemoteModal(true)}
                >
                  <PlusIcon />
                  Add Remote
                </button>
              </div>
            ) : (
              <div className="git-panel__remote-list">
                {remotes.map((remote) => (
                  <div key={remote.name} className="git-panel__remote">
                    <span className="remote-name">{remote.name}</span>
                    <span className="remote-url">{remote.url}</span>
                    <button
                      className="remote-delete"
                      onClick={() => {
                        if (confirm(`Remove remote "${remote.name}"?`)) {
                          removeRemote(remote.name);
                        }
                      }}
                      title="Remove remote"
                    >
                      <TrashIcon />
                    </button>
                  </div>
                ))}
                <button 
                  className="git-panel__add-remote-btn"
                  onClick={() => setShowAddRemoteModal(true)}
                >
                  <PlusIcon />
                  Add Remote
                </button>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Sync controls */}
      <div className="git-panel__sync">
        <button 
          className="git-panel__sync-btn git-panel__sync-btn--pull"
          onClick={handlePull}
          disabled={isPulling || remotes.length === 0}
          title={remotes.length === 0 ? 'Add a remote first' : 'Pull from remote'}
        >
          <DownloadIcon />
          {isPulling ? 'Pulling...' : 'Pull'}
        </button>
        <button 
          className="git-panel__sync-btn git-panel__sync-btn--push"
          onClick={handlePush}
          disabled={isPushing || remotes.length === 0}
          title={remotes.length === 0 ? 'Add a remote first' : 'Push to remote'}
        >
          <UploadIcon />
          {isPushing ? 'Pushing...' : 'Push'}
        </button>
      </div>

      {/* Add Remote Modal */}
      {showAddRemoteModal && (
        <div className="git-panel__modal-overlay" onClick={() => setShowAddRemoteModal(false)}>
          <div className="git-panel__modal" onClick={(e) => e.stopPropagation()}>
            <div className="git-panel__modal-header">
              <h4>Add Remote</h4>
              <button onClick={() => setShowAddRemoteModal(false)}>
                <XIcon />
              </button>
            </div>
            <div className="git-panel__modal-body">
              <div className="git-panel__form-group">
                <label>Name</label>
                <input
                  type="text"
                  value={newRemoteName}
                  onChange={(e) => setNewRemoteName(e.target.value)}
                  placeholder="origin"
                />
              </div>
              <div className="git-panel__form-group">
                <label>URL</label>
                <input
                  type="text"
                  value={newRemoteUrl}
                  onChange={(e) => setNewRemoteUrl(e.target.value)}
                  placeholder="https://github.com/user/repo.git"
                />
              </div>
              {user && (
                <p className="git-panel__hint">
                  Tip: Use format https://github.com/{user.login}/repo-name.git
                </p>
              )}
            </div>
            <div className="git-panel__modal-footer">
              <button 
                className="git-panel__modal-cancel"
                onClick={() => setShowAddRemoteModal(false)}
              >
                Cancel
              </button>
              <button 
                className="git-panel__modal-confirm"
                onClick={handleAddRemote}
                disabled={!newRemoteName.trim() || !newRemoteUrl.trim()}
              >
                Add Remote
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default GitPanel;
